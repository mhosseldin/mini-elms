import { Component, inject, OnInit } from '@angular/core';
import { Functions, httpsCallable } from '@angular/fire/functions'; // Import Functions
import {
  Firestore,
  collection,
  getDocs,
  updateDoc,
  doc,
  deleteDoc,
} from '@angular/fire/firestore';
import { Router } from '@angular/router';
import { Auth } from '@angular/fire/auth';
import { NgFor, NgForOf, NgIf } from '@angular/common';
import { NgModel } from '@angular/forms';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [NgIf, NgFor, NgForOf, FormsModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css',
})
export class AdminDashboardComponent implements OnInit {
  private firestore = inject(Firestore);
  private auth = inject(Auth);
  private router = inject(Router);
  private functions = inject(Functions);

  isLoading = true;
  courses: any[] = [];
  users: any[] = [];

  selectedInstructorId: string = '';
  selectedStudentId: string = '';

  ngOnInit() {
    // Ensure only admin access
    const currentUser = this.auth.currentUser;
    if (!currentUser) {
      this.router.navigate(['']);
      return;
    }

    this.fetchData();
  }

  async fetchData() {
    // Fetch courses
    const courseSnap = await getDocs(collection(this.firestore, 'courses'));
    this.courses = courseSnap.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));

    // Fetch users
    const userSnap = await getDocs(collection(this.firestore, 'users'));
    this.users = userSnap.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));

    this.isLoading = false;
  }

  // Assign instructor to a course
  async setInstructor(courseId: string, userId: string) {
    const courseRef = doc(this.firestore, 'courses', courseId);
    await updateDoc(courseRef, { instructorId: userId });
    alert('Instructor assigned successfully!');
  }

  // Assign student to a course
  async setStudent(userId: string, courseId: string) {
    const userRef = doc(this.firestore, 'users', userId);
    await updateDoc(userRef, {
      registeredCourses: [courseId],
    });
    alert('Student added to the course!');
  }

  // Delete user method
  async deleteUser(userId: string) {
    const userRef = doc(this.firestore, 'users', userId);

    try {
      // Call Cloud Function to delete the user from Firebase Authentication
      const deleteUserFunction = httpsCallable(this.functions, 'deleteUser');
      await deleteUserFunction({ userId });

      // Delete the user document from Firestore
      await deleteDoc(userRef);

      // Update local state
      this.users = this.users.filter((user) => user.id !== userId);
      alert('User deleted successfully!');
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  }

  navigateToRegister() {
    this.router.navigate(['/register']);
  }
}
